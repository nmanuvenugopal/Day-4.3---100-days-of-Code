import random

rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

rock_paper_scissors_list = [rock, paper, scissors]

user_choice = int(input("Enter the your choice 0:rock, 1:paper, 2:scissors "))
computer_choice = random.randint(0, len(rock_paper_scissors_list)-1)

print("User's choice:")
print(rock_paper_scissors_list[user_choice])

print("Computer's choice")
print(rock_paper_scissors_list[computer_choice])

if user_choice == 0 and computer_choice == 1:
    print("you loose")
elif user_choice == 0 and computer_choice == 2:
    print("you wins")
elif user_choice == 1 and computer_choice == 0:
    print("you wins")
elif user_choice == 1 and computer_choice == 2:
    print("you loose")
elif user_choice == 2 and computer_choice == 0:
    print("you loose")
elif user_choice == 2 and computer_choice == 1:
    print("you wins")
elif user_choice == computer_choice:
    print("You draw with computer")
else:
    print("Something went wrong")


